package vo;

import com.cinema.entity.Movies;

public class ResponseTemplateVo {
	
	
	
	private Movies movies;
	
	private ShowTimings showtimings;
	
	public ResponseTemplateVo(Movies movies, ShowTimings showtimings) {
		super();
		this.movies = movies;
		this.showtimings = showtimings;
	}

	@Override
	public String toString() {
		return "ResponseTemplateVo [movies=" + movies + ", showtimings=" + showtimings + "]";
	}

	public Movies getMovies() {
		return movies;
	}

	public void setMovies(Movies movies) {
		this.movies = movies;
	}

	public ShowTimings getShowtimings() {
		return showtimings;
	}

	public void setShowtimings(ShowTimings showtimings) {
		this.showtimings = showtimings;
	}

	public ResponseTemplateVo() {
		
		super();
	}

	
}
