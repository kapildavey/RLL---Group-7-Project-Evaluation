package com.cinema.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


import com.cinema.entity.Movies;
import com.cinema.repository.MoviesRepository;

import vo.ResponseTemplateVo;
import vo.ShowTimings;


@Service("moviesService")
@Scope("singleton")
public class MoviesService implements IMoviesService{
	
	@Autowired
	@Qualifier("moviesRepository")
	private MoviesRepository moviesRepository;

	@Override
	public List<Movies> getAllMovies() {
		return moviesRepository.findAll();
	}

	@Override
	public Movies save(Movies movieDetails) {
		return moviesRepository.save(movieDetails);
	}

	@Override
	public Movies update(Movies movieDetails) {
		
		return moviesRepository.save(movieDetails);
	}

	@Override
	public void delete(int movie_id) {
		
		moviesRepository.deleteById(movie_id);
	}

	@Override
	public Movies getMoviesById(int movie_id) {
		
		return moviesRepository.findById(movie_id).get();
	}

	@Override
	public List<Movies> getAllMoviesByTitle(String title) {
		
		return moviesRepository.findByTitleLike(title);
	}

	@Override
	public List<Movies> getAllMoviesByGenre(String genre) {
		
		return moviesRepository.findByGenreLike(genre);
	}

	@Override
	public List<Movies> getAllMoviesByLanguage(String language) {
		
		return moviesRepository.findByLanguage(language);
	}
//////////////////////
	
	@Autowired
	private RestTemplate restTemplate;
	@Override
	public ResponseTemplateVo getMoviesWithTime(int id) {


			
			  ResponseTemplateVo vo= new ResponseTemplateVo();
			  
			  Movies movies = moviesRepository.findById(id).get();
			  
			        
			  ShowTimings showTimings =restTemplate.getForObject("http://localhost:8083/getShowTimingsById/"+movies.getid(),ShowTimings.class);
			        
			    
			      vo.setMovies(movies);
			      vo.setShowtimings(showTimings);
			      return vo ;
		
		}

}
