package com.cinema;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import com.cinema.entity.Movies;
import com.cinema.repository.MoviesRepository;

@EnableEurekaClient
@SpringBootApplication
public class MovieMicroserviceApplication implements CommandLineRunner{
	
	
	@Autowired 
	@Qualifier("moviesRepository") 
	private MoviesRepository moviesRepository;

	public static void main(String[] args) {
		SpringApplication.run(MovieMicroserviceApplication.class, args);
		System.out.println("working perfectly...");
	}
	//////////////////
	@Bean
	public RestTemplate restTemplate() {
		
		return new RestTemplate();
	} 
	//////////////////////////

	@Override
	public void run(String... args) throws Exception {
		
		System.out.println("Running...!");
		
		moviesRepository.save(new Movies(0,"Kantara","Triller","Kannada",1)); 

		moviesRepository.save(new Movies(0,"KGF-2","Action","Kannada",2));

		moviesRepository.save(new Movies(0,"Gandagudi","Documentory","Kannada",3)); 

		moviesRepository.save(new Movies(0,"RRR","Action","Telugu",4)); 
		
		System.out.println(moviesRepository.findAll()); 
		
		
	}

}
