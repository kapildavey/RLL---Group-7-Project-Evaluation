package com.cinema.service;

import java.util.List;

import com.cinema.entity.Movies;

import vo.ResponseTemplateVo;


public interface IMoviesService {
	
	List<Movies> getAllMovies();
	
	Movies save(Movies movieDetails );
	
	Movies update(Movies movieDetails);
	
	void delete(int movie_id);
	
	Movies getMoviesById(int movie_id);
	
	List<Movies> getAllMoviesByTitle(String title);
	
	List<Movies> getAllMoviesByGenre(String genre);
	
	List<Movies> getAllMoviesByLanguage(String language);
	//////////////
	public ResponseTemplateVo getMoviesWithTime(int id);
////////////////
}
